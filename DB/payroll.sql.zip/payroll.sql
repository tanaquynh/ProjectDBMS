-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: payroll
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

Create database payroll;
USE payroll;
--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `username` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `ngaysinh` date NOT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES ('abc','abc','Nguyen Van A','abc@xyz.com','2001-01-01'),('quynh','123','Ta Thi Nhu Quynh','abc@gmail.com','2001-01-01');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `departmentID` varchar(20) NOT NULL,
  `departmentName` varchar(50) NOT NULL,
  PRIMARY KEY (`departmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES ('D0000','Phòng nhân sự'),('D0001','Phòng Marketing'),('D0002','Phòng hành chính'),('D0003','Phòng kế toán');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `employeeID` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gioitinh` varchar(10) NOT NULL,
  `ngaysinh` date NOT NULL,
  `positionID` varchar(20) NOT NULL,
  `departmentID` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`employeeID`),
  UNIQUE KEY `employeeID` (`employeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES ('E00000','Nguyễn Văn A','Nam','2001-01-01','P0000','D0000','Hà Nội','abc@g.com'),('E00001','Trần Văn B','Nam','2000-10-10','P0000','D0001','Hồ Chí Minh','akd@ks.com'),('E00002','Lê Thị C','Nữ','1999-01-03','P0001','D0003','Đà Nẵng','jsdh@sk.com');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nghiviec`
--

DROP TABLE IF EXISTS `nghiviec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nghiviec` (
  `nghiviecID` varchar(20) NOT NULL,
  `employeeID` varchar(20) NOT NULL,
  `absentDate` date NOT NULL,
  `reason` varchar(100) NOT NULL,
  PRIMARY KEY (`nghiviecID`),
  KEY `fk1_employee` (`employeeID`),
  CONSTRAINT `fk1_employee` FOREIGN KEY (`employeeID`) REFERENCES `employees` (`employeeID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nghiviec`
--

LOCK TABLES `nghiviec` WRITE;
/*!40000 ALTER TABLE `nghiviec` DISABLE KEYS */;
/*!40000 ALTER TABLE `nghiviec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paidsalaries`
--

DROP TABLE IF EXISTS `paidsalaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paidsalaries` (
  `paidCode` int NOT NULL,
  `employeeID` varchar(20) NOT NULL,
  `salaryID` varchar(20) NOT NULL,
  `nghiviecID` varchar(20) NOT NULL,
  `paidDay` datetime NOT NULL,
  `paidSum` int NOT NULL,
  PRIMARY KEY (`paidCode`),
  KEY `fk1_paid_employee` (`employeeID`),
  KEY `fk2_paid_nghiviec` (`nghiviecID`),
  KEY `fk3_paid_salarylevel` (`salaryID`),
  CONSTRAINT `fk1_paid_employee` FOREIGN KEY (`employeeID`) REFERENCES `employees` (`employeeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk2_paid_nghiviec` FOREIGN KEY (`nghiviecID`) REFERENCES `nghiviec` (`nghiviecID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk3_paid_salarylevel` FOREIGN KEY (`salaryID`) REFERENCES `salarylevels` (`salaryID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paidsalaries`
--

LOCK TABLES `paidsalaries` WRITE;
/*!40000 ALTER TABLE `paidsalaries` DISABLE KEYS */;
/*!40000 ALTER TABLE `paidsalaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `positions` (
  `positionID` varchar(10) NOT NULL,
  `positionName` varchar(50) NOT NULL,
  PRIMARY KEY (`positionID`),
  UNIQUE KEY `positionID` (`positionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES ('P0000','Nhân viên'),('P0001','Nhóm trưởng'),('P0002','Phó trưởng phòng'),('P0003','Trưởng phòng');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salarylevels`
--

DROP TABLE IF EXISTS `salarylevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salarylevels` (
  `salaryID` varchar(20) NOT NULL,
  `positionID` varchar(20) NOT NULL,
  `departmentID` varchar(20) NOT NULL,
  `salaryamount` int NOT NULL,
  `bonus` int NOT NULL,
  PRIMARY KEY (`salaryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salarylevels`
--

LOCK TABLES `salarylevels` WRITE;
/*!40000 ALTER TABLE `salarylevels` DISABLE KEYS */;
INSERT INTO `salarylevels` VALUES ('S0000','P0000','D0000',600000,2000000),('S0001','P0000','D0001',500000,1500000);
/*!40000 ALTER TABLE `salarylevels` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-13 15:47:23
